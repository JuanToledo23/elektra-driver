import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-car-insurance',
  templateUrl: './driver-car-insurance.component.html',
  styleUrls: ['./driver-car-insurance.component.scss']
})
export class DriverCarInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
