import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-car-tag',
  templateUrl: './driver-car-tag.component.html',
  styleUrls: ['./driver-car-tag.component.scss']
})
export class DriverCarTagComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
