import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-car-interview',
  templateUrl: './driver-car-interview.component.html',
  styleUrls: ['./driver-car-interview.component.scss']
})
export class DriverCarInterviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
