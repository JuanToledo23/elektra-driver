import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-car-driver-license',
  templateUrl: './driver-car-driver-license.component.html',
  styleUrls: ['./driver-car-driver-license.component.scss']
})
export class DriverCarDriverLicenseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
