import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-car-circulation-card',
  templateUrl: './driver-car-circulation-card.component.html',
  styleUrls: ['./driver-car-circulation-card.component.scss']
})
export class DriverCarCirculationCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
