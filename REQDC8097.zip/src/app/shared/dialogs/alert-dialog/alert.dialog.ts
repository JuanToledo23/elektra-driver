import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
    templateUrl: './alert.dialog.html'
})
export class AlertDialog implements OnInit{
    constructor() {}

    ngOnInit(): void {
    }
}